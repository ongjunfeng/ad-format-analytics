"use client";

import React, { useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoSrc: string;
  thumbnailSrc?: string;
  title?: string;
}

export function VideoModal({
  isOpen,
  onClose,
  videoSrc,
  thumbnailSrc,
  title,
}: VideoModalProps) {
  // Handle ESC key to close modal
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener("keydown", handleEscape);
      // Prevent body scroll when modal is open
      document.body.style.overflow = "hidden";
    }

    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "unset";
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const modalContent = (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[9999]"
            onClick={onClose}
          />

          {/* Modal Container - 9:16 aspect ratio */}
          <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, type: "spring", damping: 25 }}
              className="relative w-full max-w-md bg-gradient-to-br from-[#1a2332] to-[#0a1628] rounded-lg shadow-2xl overflow-hidden border border-[#1e3a5f]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-[#1e3a5f]">
                {title && (
                  <h3 className="text-sm font-semibold text-white truncate">
                    {title}
                  </h3>
                )}
                <button
                  onClick={onClose}
                  className="ml-auto p-2 hover:bg-white/10 rounded-full transition-colors flex-shrink-0"
                  aria-label="Close modal"
                >
                  <X className="h-5 w-5 text-gray-400 hover:text-white" />
                </button>
              </div>

              {/* Video Content - 9:16 aspect ratio */}
              <div className="relative w-full aspect-[9/16] bg-black">
                <video
                  src={videoSrc}
                  poster={thumbnailSrc}
                  controls
                  className="w-full h-full object-contain"
                  autoPlay
                  playsInline
                >
                  Your browser does not support the video tag.
                </video>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );

  // Render modal in portal
  return createPortal(modalContent, document.body);
}
