"use client";

import { useEffect, useState } from "react";
import { cn, ui } from "@/lib/design-system";
import { ViralNonviralContainer } from "./components/viral-nonviral-container";
import { ObservationsContainer } from "./components/observations-container";
import { HypothesesDisplayContainer } from "./components/hypotheses-display-container";

interface VideoAnalysis {
  post_id: string;
  video_path: string;
  metadata: {
    Captions: string;
    Likes: number;
    Comments: number;
    Views: number;
    Date: string;
    "Video Duration": number;
    engagement: number;
    viral: boolean;
  };
  video_analysis: string;
  performance_context: string;
  virality_analysis: string;
}

interface Observation {
  category: string;
  winners: string;
  losers: string;
  overlap: string;
  key_difference: string;
}

interface Hypothesis {
  id: number;
  name: string;
  hypothesis: string;
  reasoning: string;
  validation_method: string;
  success_metrics: string[];
}

export default function NUSDashboardPage() {
  const [viralVideos, setViralVideos] = useState<VideoAnalysis[]>([]);
  const [nonViralVideos, setNonViralVideos] = useState<VideoAnalysis[]>([]);
  const [observations, setObservations] = useState<Observation[]>([]);
  const [hypotheses, setHypotheses] = useState<Hypothesis[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);

        // Load all JSON files in parallel
        const [viralResponse, nonViralResponse, observationsResponse, hypothesesResponse] =
          await Promise.all([
            fetch("/nus-ad-data/viral_video_analyses.json"),
            fetch("/nus-ad-data/non_viral_video_analyses.json"),
            fetch("/nus-ad-data/scraped_data_observations.json"),
            fetch("/nus-ad-data/scraped_data_hypotheses.json"),
          ]);

        const viralData = await viralResponse.json();
        const nonViralData = await nonViralResponse.json();
        const observationsData = await observationsResponse.json();
        const hypothesesData = await hypothesesResponse.json();

        setViralVideos(viralData);
        setNonViralVideos(nonViralData);
        setObservations(observationsData);
        setHypotheses(hypothesesData);
      } catch (error) {
        console.error("Error loading NUS data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  // Combine viral and non-viral videos
  const allVideos = [...viralVideos, ...nonViralVideos];

  return (
    <div className={cn(ui.page, "px-6")}>
      <div className={cn(ui.container)}>
        {/* Header */}
        <div className="flex items-center justify-between px-0 pt-8 pb-4">
          <h1 className={cn(ui.h1)} style={{ color: "#e7bb57" }}>
            NUS Video Analysis
          </h1>
        </div>

        {/* Main Components Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[85vh]">
          <ViralNonviralContainer data={allVideos} isLoading={isLoading} />
          <ObservationsContainer data={observations} isLoading={isLoading} />
          <HypothesesDisplayContainer data={hypotheses} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}
