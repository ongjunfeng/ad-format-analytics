"use client";

import { Loader2, type LucideIcon } from "lucide-react";
import { type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn, ui } from "@/lib/design-system";

export interface BaseContainerProps {
  title: string;
  icon: LucideIcon;
  iconColor?: string;
  isLoading?: boolean;
  error?: string | null;
  data?: unknown;
  children?: ReactNode;
  className?: string;
  emptyStateMessage?: string;
  onRetry?: () => void;
  headerAction?: ReactNode;
}

export function BaseContainer({
  title,
  icon: Icon,
  iconColor = "text-gray-500",
  isLoading = false,
  error,
  data,
  children,
  className,
  emptyStateMessage,
  onRetry,
  headerAction,
}: BaseContainerProps) {
  // Loading state
  if (isLoading && !data) {
    return (
      <Card className={cn(ui.card, "h-full flex flex-col bg-[#1a2332] border-[#1e3a5f]", className)}>
        <CardHeader className="flex-shrink-0 pb-4">
          <CardTitle className="flex items-center gap-2 text-lg text-gray-400">
            <Icon className="h-5 w-5" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
        </CardContent>
      </Card>
    );
  }

  // Error state
  if (error) {
    return (
      <Card className={cn(ui.card, "h-full flex flex-col bg-[#1a2332] border-[#1e3a5f]", className)}>
        <CardHeader className="flex-shrink-0 pb-4">
          <CardTitle className="flex items-center gap-2 text-lg text-white">
            <Icon className="h-5 w-5 text-red-500" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col items-center justify-center text-center">
          <Icon className="h-8 w-8 text-red-500 mb-2" />
          <p className="text-gray-400 mb-4">{error}</p>
          {onRetry && (
            <Button
              onClick={onRetry}
              variant="outline"
              size="sm"
              className="border-[#2d4a6f] text-white hover:bg-[#253449]"
            >
              Try Again
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  // Empty state (no data or loading without external data)
  if (!data && !isLoading) {
    return (
      <Card
        className={cn(
          ui.card,
          "h-full flex flex-col bg-[#1a2332] border-[#1e3a5f] overflow-y-auto",
          className
        )}
      >
        <CardHeader className="flex-shrink-0 pb-4">
          <CardTitle className="flex items-center gap-2 text-lg text-white">
            <Icon className="h-5 w-5" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col items-center justify-center">
          <div className="text-center">
            <Icon className="h-8 w-8 text-gray-500 mb-2 mx-auto" />
            <p className="text-gray-400 mb-4">
              {emptyStateMessage || `No ${title.toLowerCase()} available`}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Content state
  return (
    <Card
      className={cn(
        ui.card,
        "h-full flex flex-col overflow-y-auto pt-4 bg-[#1a2332] border-[#1e3a5f]",
        className
      )}
    >
      <CardHeader className="flex-shrink-0">
        <CardTitle className="flex items-center justify-between text-lg text-white">
          <div className="flex items-center gap-2">
            <Icon className={cn("h-5 w-5", iconColor)} />
            {title}
            {isLoading && <Loader2 className="h-4 w-4 animate-spin text-gray-400" />}
          </div>
          {headerAction && <div className="flex items-center gap-2">{headerAction}</div>}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto space-y-4 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-[#1a2332] [&::-webkit-scrollbar-thumb]:bg-[#2d4a6f] [&::-webkit-scrollbar-thumb:hover]:bg-[#3a5a87]">
        {children}
      </CardContent>
    </Card>
  );
}
