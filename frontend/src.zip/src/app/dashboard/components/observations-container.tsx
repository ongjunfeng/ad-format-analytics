"use client";

import { FileText } from "lucide-react";
import { useState } from "react";
import { CardContent } from "@/components/ui/card";
import { ExpandingCard } from "@/components/ui/expanding-card";
import { BaseContainer } from "./base-container";

interface Observation {
  category: string;
  winners: string;
  losers: string;
  overlap: string;
  key_difference: string;
}

interface ObservationsContainerProps {
  data: Observation[];
  isLoading?: boolean;
}

export function ObservationsContainer({ data, isLoading = false }: ObservationsContainerProps) {
  const [expandedCardId, setExpandedCardId] = useState<string | null>(null);

  return (
    <BaseContainer
      title="Observations"
      icon={FileText}
      iconColor="text-blue-500"
      isLoading={isLoading}
      data={data}
      emptyStateMessage="No observations available"
    >
      {data.length > 0 ? (
        data.map((item, index) => (
          <ExpandingCard
            key={`${item.category}-${index}`}
            id={`${item.category}-${index}`}
            isExpanded={expandedCardId === `${item.category}-${index}`}
            onExpandAction={(id) => setExpandedCardId(id)}
            onCollapseAction={() => setExpandedCardId(null)}
            expandedWidth={500}
            expandedHeight={500}
            cardClassName="border-gray-700 bg-gray-800 hover:border-gray-600"
            expandedCardClassName="border-gray-700 bg-gray-800"
            expandedContent={
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-gray-100 capitalize">
                  {item.category}
                </h3>

                <div className="space-y-3">
                  <div className="p-3 bg-green-950/20 rounded-md border border-gray-700">
                    <h4 className="font-medium text-green-400 mb-1 text-sm">Winners</h4>
                    <p className="text-xs text-gray-100">{item.winners}</p>
                  </div>

                  <div className="p-3 bg-red-950/20 rounded-md border border-gray-700">
                    <h4 className="font-medium text-red-400 mb-1 text-sm">Losers</h4>
                    <p className="text-xs text-gray-100">{item.losers}</p>
                  </div>

                  {item.overlap && (
                    <div className="p-3 bg-blue-950/20 rounded-md border border-gray-700">
                      <h4 className="font-medium text-gray-100 mb-1 text-sm">Overlap</h4>
                      <p className="text-xs text-gray-100">{item.overlap}</p>
                    </div>
                  )}

                  {item.key_difference && (
                    <div className="p-3 bg-amber-950/20 rounded-md border border-gray-700">
                      <h4 className="font-medium text-amber-400 mb-1 text-sm">Key Difference</h4>
                      <p className="text-xs text-gray-100">{item.key_difference}</p>
                    </div>
                  )}
                </div>
              </div>
            }
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-2 text-gray-100 capitalize">
                    {item.category}
                  </h4>
                  <div className="space-y-2">
                    <div>
                      <span className="text-xs font-medium text-green-400">Winners: </span>
                      <span className="text-xs text-gray-100">
                        {item.winners.substring(0, 60)}...
                      </span>
                    </div>
                    <div>
                      <span className="text-xs font-medium text-red-400">Losers: </span>
                      <span className="text-xs text-gray-100">
                        {item.losers.substring(0, 60)}...
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </ExpandingCard>
        ))
      ) : (
        <div className="flex flex-col items-center justify-center h-32 text-center">
          <FileText className="h-8 w-8 text-gray-500 mb-2" />
          <p className="text-gray-400">No observations available</p>
        </div>
      )}
    </BaseContainer>
  );
}
