"use client";

import { Lightbulb, Target } from "lucide-react";
import { useState } from "react";
import { CardContent } from "@/components/ui/card";
import { ExpandingCard } from "@/components/ui/expanding-card";
import { BaseContainer } from "./base-container";

interface Hypothesis {
  id: number;
  name: string;
  hypothesis: string;
  reasoning: string;
  validation_method: string;
  success_metrics: string[];
}

interface HypothesesDisplayContainerProps {
  data: Hypothesis[];
  isLoading?: boolean;
}

export function HypothesesDisplayContainer({
  data,
  isLoading = false,
}: HypothesesDisplayContainerProps) {
  const [expandedCardId, setExpandedCardId] = useState<string | null>(null);

  return (
    <BaseContainer
      title="Hypotheses"
      icon={Lightbulb}
      iconColor="text-yellow-500"
      isLoading={isLoading}
      data={data}
      emptyStateMessage="No hypotheses available"
    >
      {data.map((item) => {
        const itemId = `hypothesis-${item.id}`;
        return (
          <ExpandingCard
            key={itemId}
            id={itemId}
            isExpanded={expandedCardId === itemId}
            onExpandAction={(id) => setExpandedCardId(id)}
            onCollapseAction={() => setExpandedCardId(null)}
            expandedWidth={500}
            expandedHeight={500}
            cardClassName="border-gray-700 bg-gray-800 hover:border-gray-600"
            expandedCardClassName="border-gray-700 bg-gray-800"
            expandedContent={
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <Lightbulb className="h-5 w-5 text-yellow-400 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-100 mb-2">{item.name}</h3>
                    <p className="text-sm text-gray-100 mb-4 leading-relaxed">{item.hypothesis}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-blue-950/20 rounded-lg border border-gray-700">
                    <h4 className="font-medium text-blue-400 mb-2 text-sm">Reasoning</h4>
                    <p className="text-sm text-gray-100 leading-relaxed">{item.reasoning}</p>
                  </div>

                  <div className="p-3 bg-yellow-950/20 rounded-lg border border-gray-700">
                    <h4 className="font-medium text-yellow-400 mb-2 text-sm">Validation Method</h4>
                    <p className="text-sm text-gray-100 leading-relaxed">{item.validation_method}</p>
                  </div>

                  {item.success_metrics && item.success_metrics.length > 0 && (
                    <div className="p-3 bg-green-950/20 rounded-lg border border-gray-700">
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="h-4 w-4 text-green-400" />
                        <h4 className="font-medium text-green-400 text-sm">Success Metrics</h4>
                      </div>
                      <ul className="space-y-1">
                        {item.success_metrics.map((metric, index) => (
                          <li
                            key={index}
                            className="text-sm text-gray-100 flex items-start gap-2 leading-relaxed"
                          >
                            <span className="text-green-400 text-xs font-bold mt-0.5 flex-shrink-0">
                              →
                            </span>
                            <span>{metric}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            }
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-2 mb-2">
                <div className="flex-1">
                  <h4 className="font-semibold text-sm text-gray-100 mb-1">{item.name}</h4>
                  <p className="text-xs text-gray-100 line-clamp-2 mb-2">{item.hypothesis}</p>
                  <div className="text-xs text-gray-400">
                    <span className="font-medium text-yellow-400">Validation:</span>{" "}
                    {item.validation_method.substring(0, 80)}...
                  </div>
                </div>
              </div>
            </CardContent>
          </ExpandingCard>
        );
      })}
    </BaseContainer>
  );
}
