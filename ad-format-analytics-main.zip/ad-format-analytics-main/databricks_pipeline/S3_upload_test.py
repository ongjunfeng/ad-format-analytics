# Databricks notebook source
!pip install dotenv

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import aws_service