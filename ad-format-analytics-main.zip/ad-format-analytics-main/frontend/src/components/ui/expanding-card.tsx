"use client";

import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { type ReactNode, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/design-system";

// Smart positioning function
function getSmartCornerPosition(
  rect: DOMRect,
  expandedWidth: number,
  expandedHeight: number,
  margin = 20
) {
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  let top = rect.top + window.scrollY;
  let left = rect.left;

  // Shift left if overflows right
  if (left + expandedWidth > viewportWidth - margin) {
    left = Math.max(margin, rect.right - expandedWidth);
  }

  // Shift up if overflows bottom
  if (top + expandedHeight > viewportHeight + window.scrollY - margin) {
    top = Math.max(margin + window.scrollY, rect.bottom + window.scrollY - expandedHeight);
  }

  return { top, left, width: expandedWidth, height: expandedHeight };
}

interface ExpandingCardProps {
  id: string;
  isExpanded: boolean;
  onExpandAction: (id: string) => void;
  onCollapseAction: () => void;
  expandedWidth?: number;
  expandedHeight?: number;
  cardClassName?: string;
  expandedCardClassName?: string;
  children: ReactNode;
  expandedContent: ReactNode;
}

export const ExpandingCard: React.FC<ExpandingCardProps> = ({
  id,
  isExpanded,
  onExpandAction,
  onCollapseAction,
  expandedWidth = 500,
  expandedHeight = 400,
  cardClassName,
  expandedCardClassName,
  children,
  expandedContent,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const expandedRef = useRef<HTMLDivElement>(null);
  const [originalRect, setOriginalRect] = useState<DOMRect | null>(null);
  const [targetPosition, setTargetPosition] = useState<{
    top: number;
    left: number;
    width: number;
    height: number;
  } | null>(null);

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isExpanded &&
        expandedRef.current &&
        !expandedRef.current.contains(event.target as Node)
      ) {
        onCollapseAction();
      }
    };

    if (isExpanded) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [isExpanded, onCollapseAction]);

  const handleCardClick = () => {
    if (!isExpanded && cardRef.current) {
      const rect = cardRef.current.getBoundingClientRect();
      setOriginalRect(rect);

      // Calculate expanded dimensions and smart position
      const target = getSmartCornerPosition(rect, expandedWidth, expandedHeight);
      setTargetPosition(target);
      onExpandAction(id);
    }
  };

  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    onCollapseAction();
  };

  return (
    <>
      <Card
        ref={cardRef}
        className={cn(
          "transition-all duration-300 ease-out cursor-pointer transform-gpu border-2",
          "hover:shadow-lg hover:shadow-black/10 dark:hover:shadow-black/30",
          isExpanded && "opacity-20", // Dim when expanded
          cardClassName
        )}
        onClick={handleCardClick}
      >
        {children}
      </Card>

      {/* Portal expansion - animated style */}
      {isExpanded &&
        originalRect &&
        targetPosition &&
        createPortal(
          <AnimatePresence>
            <motion.div
              ref={expandedRef}
              initial={{
                position: "fixed",
                top: originalRect.top + window.scrollY,
                left: originalRect.left,
                width: originalRect.width,
                height: originalRect.height,
                zIndex: 9999,
              }}
              animate={{
                top: targetPosition.top,
                left: targetPosition.left,
                width: targetPosition.width,
                height: targetPosition.height,
              }}
              exit={{
                top: originalRect.top + window.scrollY,
                left: originalRect.left,
                width: originalRect.width,
                height: originalRect.height,
                transition: { duration: 0.4, ease: "easeInOut" },
              }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              style={{
                position: "fixed",
                zIndex: 9999,
              }}
            >
              <Card
                className={cn(
                  "h-full w-full border-2 shadow-2xl shadow-black/30 dark:shadow-black/50 relative",
                  expandedCardClassName
                )}
              >
                {/* Close button */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 right-2 h-8 w-8 p-0 hover:bg-gray-200 dark:hover:bg-gray-700 z-10"
                  onClick={handleClose}
                >
                  <X className="h-4 w-4" />
                </Button>

                <CardContent className="p-6 overflow-auto dark-scrollbar max-h-full">
                  {expandedContent}
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>,
          document.body
        )}
    </>
  );
};
