"use client";

import React, { useEffect, useRef, useState } from "react";

interface VideoThumbnailProps {
  videoSrc?: string;
  thumbnailSrc?: string;
  alt: string;
  width: number;
  height: number;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
}

export function VideoThumbnail({
  videoSrc,
  thumbnailSrc,
  alt,
  width,
  height,
  className = "",
  onClick,
}: VideoThumbnailProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(thumbnailSrc || null);
  const [isLoading, setIsLoading] = useState(!thumbnailSrc);

  useEffect(() => {
    // If thumbnailSrc is provided, use it directly
    if (thumbnailSrc) {
      setThumbnailUrl(thumbnailSrc);
      setIsLoading(false);
      return;
    }

    // Otherwise, fall back to video frame extraction
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas || !videoSrc) return;

    let hasGenerated = false;

    const generateThumbnail = () => {
      if (hasGenerated) return;

      try {
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        // Set canvas size
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        // Draw the video frame
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Convert canvas to data URL (fallback if CORS fails)
        try {
          const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
          setThumbnailUrl(dataUrl);
          setIsLoading(false);
          hasGenerated = true;
        } catch (e) {
          console.error("Canvas toDataURL failed, trying without CORS:", e);
          // If CORS fails, we can't extract the thumbnail
          setIsLoading(false);
        }
      } catch (err) {
        console.error("Error generating thumbnail:", err);
        setIsLoading(false);
      }
    };

    const handleLoadedData = () => {
      // Once we have enough data, seek to 1 second
      if (video.duration >= 1) {
        video.currentTime = 1;
      } else {
        video.currentTime = 0.1; // If video is shorter, use 0.1s
      }
    };

    const handleSeeked = () => {
      // After seeking completes, generate the thumbnail
      generateThumbnail();
    };

    // Set up event listeners
    video.addEventListener("loadeddata", handleLoadedData);
    video.addEventListener("seeked", handleSeeked);

    // Cleanup
    return () => {
      video.removeEventListener("loadeddata", handleLoadedData);
      video.removeEventListener("seeked", handleSeeked);
    };
  }, [videoSrc, thumbnailSrc]);

  return (
    <div
      className="relative"
      onClick={onClick}
      style={{
        width: `${width}px`,
        height: `${height}px`,
      }}
    >
      {/* Hidden video element */}
      <video
        ref={videoRef}
        src={videoSrc}
        crossOrigin="anonymous"
        preload="auto"
        muted
        playsInline
        style={{ display: "none" }}
      />

      {/* Hidden canvas for frame extraction */}
      <canvas ref={canvasRef} style={{ display: "none" }} />

      {/* Display thumbnail */}
      {thumbnailUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={thumbnailUrl}
          alt={alt}
          className={className}
          style={{
            width: `${width}px`,
            height: `${height}px`,
            objectFit: "cover",
          }}
        />
      )}

      {/* Loading placeholder */}
      {isLoading && (
        <div className="absolute inset-0 bg-gray-800 animate-pulse flex items-center justify-center">
          <svg
            className="w-6 h-6 text-gray-600"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        </div>
      )}
    </div>
  );
}
