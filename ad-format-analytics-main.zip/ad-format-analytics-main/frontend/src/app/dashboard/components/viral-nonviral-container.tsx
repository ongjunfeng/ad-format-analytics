"use client";

import { TrendingUp, TrendingDown, Eye, Heart, MessageCircle, Calendar } from "lucide-react";
import { useState } from "react";
import { CardContent } from "@/components/ui/card";
import { ExpandingCard } from "@/components/ui/expanding-card";
import { cn } from "@/lib/design-system";
import { BaseContainer } from "./base-container";
import { VideoModal } from "@/components/ui/video-modal";
import { VideoThumbnail } from "@/components/ui/video-thumbnail";
import { MarkdownFormatter } from "@/lib/markdown-formatter";

interface VideoMetadata {
  Captions: string;
  Likes: number;
  Comments: number;
  Views: number;
  Date: string;
  "Video Duration": number;
  engagement: number;
  viral: boolean;
}

interface VideoAnalysis {
  post_id: string;
  video_path: string;
  metadata: VideoMetadata;
  video_analysis: string;
  performance_context: string;
  virality_analysis: string;
}

interface ViralNonviralContainerProps {
  data: VideoAnalysis[];
  isLoading?: boolean;
}

export function ViralNonviralContainer({ data, isLoading = false }: ViralNonviralContainerProps) {
  const [expandedCardId, setExpandedCardId] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<VideoAnalysis | null>(null);

  const getVideoUrl = (postId: string, isViral: boolean): string => {
    const namespace = isViral ? "viral" : "non_viral";
    return `https://d2i3hjw4ptoo7c.cloudfront.net/nus/dataset_91qIDxbbk340bcKdW/${namespace}/${postId}.mp4`;
  };

  const getThumbnailUrl = (postId: string, isViral: boolean): string => {
    const namespace = isViral ? "viral" : "non_viral";
    return `https://d2i3hjw4ptoo7c.cloudfront.net/nus/dataset_91qIDxbbk340bcKdW/${namespace}/${postId}.png`;
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
  };

  const truncateText = (text: string, maxLength: number): string => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  return (
    <BaseContainer
      title="Viral vs Non-Viral"
      icon={TrendingUp}
      iconColor="text-purple-500"
      isLoading={isLoading}
      data={data}
    >
      {data.map((video) => {
        const isViral = video.metadata.viral;
        const itemId = video.post_id;

        return (
          <ExpandingCard
            key={itemId}
            id={itemId}
            isExpanded={expandedCardId === itemId}
            onExpandAction={(id: string) => setExpandedCardId(id)}
            onCollapseAction={() => setExpandedCardId(null)}
            expandedWidth={700}
            expandedHeight={620}
            cardClassName={cn(
              isViral
                ? "border-green-800 bg-gray-800 hover:border-green-700"
                : "border-gray-700 bg-gray-800 hover:border-gray-600"
            )}
            expandedCardClassName={cn(
              isViral ? "border-green-800 bg-gray-800" : "border-gray-700 bg-gray-800"
            )}
            expandedContent={
              <div className="space-y-4">
                {/* Header with viral status */}
                <div className="flex items-start gap-2">
                  {isViral ? (
                    <TrendingUp className="text-green-600 mt-1 flex-shrink-0 h-5 w-5" />
                  ) : (
                    <TrendingDown className="text-gray-500 mt-1 flex-shrink-0 h-5 w-5" />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-lg" style={{ color: "#e7bb57" }}>
                        {isViral ? "Viral Video" : "Non-Viral Video"}
                      </h4>
                      <span
                        className={cn(
                          "px-2 py-0.5 rounded-full text-xs font-medium",
                          isViral
                            ? "bg-green-900/30 text-green-400 border border-green-700"
                            : "bg-gray-700/30 text-gray-400 border border-gray-600"
                        )}
                      >
                        {video.post_id}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Metrics Section */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-blue-950/20 p-2 rounded-lg border border-blue-800">
                    <div className="flex items-center gap-1 mb-1">
                      <Eye className="h-3 w-3 text-blue-400" />
                      <span className="font-semibold text-xs text-blue-200">Views</span>
                    </div>
                    <p className="text-sm text-gray-100 font-bold">
                      {formatNumber(video.metadata.Views)}
                    </p>
                  </div>

                  <div className="bg-pink-950/20 p-2 rounded-lg border border-pink-800">
                    <div className="flex items-center gap-1 mb-1">
                      <Heart className="h-3 w-3 text-pink-400" />
                      <span className="font-semibold text-xs text-pink-200">Likes</span>
                    </div>
                    <p className="text-sm text-gray-100 font-bold">
                      {formatNumber(video.metadata.Likes)}
                    </p>
                  </div>

                  <div className="bg-purple-950/20 p-2 rounded-lg border border-purple-800">
                    <div className="flex items-center gap-1 mb-1">
                      <MessageCircle className="h-3 w-3 text-purple-400" />
                      <span className="font-semibold text-xs text-purple-200">Comments</span>
                    </div>
                    <p className="text-sm text-gray-100 font-bold">
                      {formatNumber(video.metadata.Comments)}
                    </p>
                  </div>
                </div>

                {/* Additional metadata */}
                <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700 space-y-2">
                  <div className="flex items-center gap-2 text-xs">
                    <Calendar className="h-3 w-3 text-gray-400" />
                    <span className="text-gray-400">Posted:</span>
                    <span className="text-gray-200">{formatDate(video.metadata.Date)}</span>
                  </div>
                  <div className="text-xs">
                    <span className="text-gray-400">Engagement Rate:</span>
                    <span className="text-gray-200 ml-2 font-semibold">
                      {((video.metadata.engagement / video.metadata.Views) * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="text-xs">
                    <span className="text-gray-400">Duration:</span>
                    <span className="text-gray-200 ml-2">
                      {video.metadata["Video Duration"].toFixed(1)}s
                    </span>
                  </div>
                </div>

                {/* Caption */}
                <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                  <h5 className="font-medium text-xs text-gray-400 mb-1">Caption</h5>
                  <p className="text-xs text-gray-100 italic">&ldquo;{video.metadata.Captions}&rdquo;</p>
                </div>

                {/* Virality Analysis */}
                <div
                  className={cn(
                    "p-3 rounded-lg border",
                    isViral
                      ? "bg-green-950/20 border-green-800"
                      : "bg-gray-800/50 border-gray-700"
                  )}
                >
                  <h5
                    className={cn(
                      "font-medium text-sm mb-3",
                      isViral ? "text-green-400" : "text-gray-400"
                    )}
                  >
                    Virality Analysis
                  </h5>
                  <MarkdownFormatter
                    text={video.virality_analysis}
                    className="text-xs text-gray-100"
                  />
                </div>
              </div>
            }
          >
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  {isViral ? (
                    <TrendingUp className="text-green-600 mt-1 flex-shrink-0 h-4 w-4" />
                  ) : (
                    <TrendingDown className="text-gray-500 mt-1 flex-shrink-0 h-4 w-4" />
                  )}
                  {/* Video Thumbnail */}
                  <div className="flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity rounded overflow-hidden border border-[#e7bb57]/50 hover:border-[#e7bb57]">
                    <VideoThumbnail
                      thumbnailSrc={getThumbnailUrl(video.post_id, isViral)}
                      videoSrc={getVideoUrl(video.post_id, isViral)}
                      alt="Video thumbnail"
                      width={56}
                      height={100}
                      className="object-cover rounded"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedVideo(video);
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-sm" style={{ color: "#e7bb57" }}>
                        {isViral ? "Viral" : "Non-Viral"}
                      </h4>
                      <span className="text-xs text-gray-500">{video.post_id}</span>
                    </div>
                    <p className="text-gray-100 text-xs mb-2">
                      {truncateText(video.virality_analysis, 120)}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {formatNumber(video.metadata.Views)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="h-3 w-3" />
                        {formatNumber(video.metadata.Likes)}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="h-3 w-3" />
                        {formatNumber(video.metadata.Comments)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </ExpandingCard>
        );
      })}

      {/* Video Modal */}
      {selectedVideo && (
        <VideoModal
          isOpen={selectedVideo !== null}
          onClose={() => setSelectedVideo(null)}
          videoSrc={getVideoUrl(selectedVideo.post_id, selectedVideo.metadata.viral)}
          title={`Video: ${selectedVideo.post_id}`}
        />
      )}
    </BaseContainer>
  );
}
