import pandas as pd
import numpy as np
import json

def _ensure_numeric(series, default=0):
    # Coerce to numeric and fill NaNs
    return pd.to_numeric(series, errors='coerce').fillna(default)

def _compute_engagement(df):
    # --- 1. Convert and clean date ---
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df['date'] = df['date'].dt.tz_localize(None)

    # --- 2. Coerce key numeric columns ---
    numeric_cols = ['likes', 'views', 'comments', 'duration']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = _ensure_numeric(df[col], default=0)
        else:
            df[col] = 0  # create missing columns as zeros

    # --- 3. Sort (latest first) ---
    df = df.sort_values(['username', 'date'], ascending=[True, False])

    # --- 4. Rank posts (latest = 1, oldest = n) ---
    df['post_number'] = df.groupby('username').cumcount() + 1

    # --- 5. Filter out accounts with <100 posts ---
    df = df.groupby('username').filter(lambda x: len(x) >= 100)

    # --- 6. Sort by username and chronological post_number ---
    df = df.sort_values(['username', 'post_number']).reset_index(drop=True)

    # --- 7. Compute average likes of next 50 posts (look-ahead rolling mean) ---
    def avg_next_50(likes):
        return likes[::-1].rolling(window=50, min_periods=50).mean()[::-1].shift(-1)

    df['avg_last_50'] = (
        df.groupby('username', group_keys=False)['likes']
        .apply(avg_next_50)
    )

    # --- 8. Label viral posts (likes > 115% of avg_next_50) ---
    df['viral'] = (df['likes'] > df['avg_last_50'] * 1.15).astype(int)

    # --- 9. Limit to first 50 posts per user ---
    df = df.groupby('username').head(50)

    # --- 10. Verification output ---
    print(df[['username', 'post_number', 'likes', 'avg_last_50', 'viral']])

    return df

# def get_top_engagement_from_both(ad_data_path, cat_data_path, top_percent=0.2):
#     """
#     - Reads two Excel files (ads & scraped/cat content)
#     - Ensures/derives an 'engagement' column
#     - Labels each row as viral (True) if in the top `top_percent` by engagement
#     - Saves outputs as labeled_ad_data.json and labeled_scraped_data.json
#     """
#     # --- Ads data (commonly lowercase col names) ---
#     ad_df = pd.read_excel(ad_data_path)
#     # Try common lowercase names; fall back to case-insensitive match if needed
#     ad_cols_lower = {c.lower(): c for c in ad_df.columns}
#     likes_col_ads = ad_cols_lower.get('likes', 'likes' if 'likes' in ad_df.columns else None)
#     comments_col_ads = ad_cols_lower.get('comments', 'comments' if 'comments' in ad_df.columns else None)

#     # Compute engagement robustly (missing cols default to 0)
#     ad_df = _compute_engagement(ad_df, likes_col_ads or 'likes', comments_col_ads or 'comments')

#     # Threshold & label
#     if len(ad_df) > 0:
#         ad_threshold = np.quantile(ad_df['engagement'], 1 - top_percent) if ad_df['engagement'].nunique() > 1 else ad_df['engagement'].max()
#         ad_df['viral'] = ad_df['engagement'] >= ad_threshold
#     else:
#         ad_df['viral'] = pd.Series([], dtype=bool)

#     ad_df['source'] = 'ads'

#     # --- Cat/scraped data (often capitalized col names) ---
#     cat_df = pd.read_excel(cat_data_path)
#     # Try typical capitalized names; fall back to case-insensitive
#     cat_cols_lower = {c.lower(): c for c in cat_df.columns}
#     likes_col_cats = cat_cols_lower.get('likes', 'Likes' if 'Likes' in cat_df.columns else None)
#     comments_col_cats = cat_cols_lower.get('comments', 'Comments' if 'Comments' in cat_df.columns else None)

#     # Compute engagement (treat missing Comments as 0 to support “no comments” sheets)
#     cat_df = _compute_engagement(cat_df, likes_col_cats or 'Likes', comments_col_cats or 'Comments')

#     # Threshold & label
#     if len(cat_df) > 0:
#         cat_threshold = np.quantile(cat_df['engagement'], 1 - top_percent) if cat_df['engagement'].nunique() > 1 else cat_df['engagement'].max()
#         cat_df['viral'] = cat_df['engagement'] >= cat_threshold
#     else:
#         cat_df['viral'] = pd.Series([], dtype=bool)

#     cat_df['source'] = 'cats'

#     # --- Save labeled outputs ---
#     # Clean string columns to remove escaped characters from source data
#     for col in ad_df.select_dtypes(include=['object']).columns:
#         ad_df[col] = ad_df[col].astype(str).str.replace(r'\/', '/', regex=False).str.replace('\\n', '\n', regex=False).replace('nan', pd.NA)

#     for col in cat_df.select_dtypes(include=['object']).columns:
#         cat_df[col] = cat_df[col].astype(str).str.replace(r'\/', '/', regex=False).str.replace('\\n', '\n', regex=False).replace('nan', pd.NA)

#     # Convert datetime/timestamp columns to strings for JSON serialization
#     for col in ad_df.select_dtypes(include=['datetime64']).columns:
#         ad_df[col] = ad_df[col].astype(str)

#     for col in cat_df.select_dtypes(include=['datetime64']).columns:
#         cat_df[col] = cat_df[col].astype(str)

#     # Replace NaN with None for proper JSON null serialization
#     ad_df = ad_df.replace({np.nan: None})
#     cat_df = cat_df.replace({np.nan: None})

#     # Convert to dict and save with json module for cleaner output
#     with open('labeled_ad_data.json', 'w', encoding='utf-8') as f:
#         json.dump(ad_df.to_dict(orient='records'), f, ensure_ascii=False, indent=2)

#     with open('labeled_scraped_data.json', 'w', encoding='utf-8') as f:
#         json.dump(cat_df.to_dict(orient='records'), f, ensure_ascii=False, indent=2)

#     # Optionally return the thresholds if you want to log/debug
#     return {
#         'ad_threshold': float(ad_df['engagement'].quantile(1 - top_percent)) if len(ad_df) else None,
#         'cat_threshold': float(cat_df['engagement'].quantile(1 - top_percent)) if len(cat_df) else None
#     }

# # Example usage:
# result = get_top_engagement_from_both("Ad Level Data.xlsx", "cat_data (no comments).xlsx")
# # Files written: labeled_ad_data.json, labeled_scraped_data.json
